package com.testing.complexTest;


import org.junit.jupiter.api.Test;

import com.testing.complex.StringOperations;

import static org.junit.jupiter.api.Assertions.*;

class StringOperationsTest {

    @Test
    void testReverseString() {
        String input = "Hello, world!";
        String expected = "!dlrow ,olleH";
        String actual = StringOperations.reverseString(input);
        assertEquals(expected, actual);
    }

    @Test
    void testCapitalizeString() {
        String input = "the quick brown fox";
        String expected = "The Quick Brown Fox";
        String actual = StringOperations.capitalizeString(input);
        assertEquals(expected, actual);
    }

    @Test
    void testIsPalindrome() {
        String input1 = "racecar";
        assertTrue(StringOperations.isPalindrome(input1));
        
        String input2 = "hello";
        assertFalse(StringOperations.isPalindrome(input2));
    }

}
