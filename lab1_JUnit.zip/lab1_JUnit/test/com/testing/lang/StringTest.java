package com.testing.lang;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StringTest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
//	
	@Test 
	public void testLength() {
		String s = "JUnit Rules";
		assertTrue(11 == s.length());
	}

	@Test
	public void testSubstring() {
	  String str = "Hello, world!";
	  
	  // Test substring with starting index only
	  assertEquals("Hello", str.substring(0, 5));
	  
	  // Test substring with starting index and ending index
	  assertEquals("world", str.substring(7, 12));
	  
	  // Test substring with starting index and ending index equal to string length
	  assertEquals("world!", str.substring(7));
	  
	  // Test substring with negative starting index
//	  assertEquals("world!", str.substring(-6));
	  
	  // Test substring with negative starting index and ending index
//	  assertEquals("o, wor", str.substring(-9, 5));
	  
	  // Test substring with starting index greater than ending index
	  assertEquals("", str.substring(7, 2));
	  
	  // Test substring with starting index equal to ending index
	  assertEquals("", str.substring(7, 7));
	  
	  // Test substring with starting index and ending index out of range
	  assertThrows(IndexOutOfBoundsException.class, () -> str.substring(15));
	  assertThrows(IndexOutOfBoundsException.class, () -> str.substring(7, 15));
	  assertThrows(IndexOutOfBoundsException.class, () -> str.substring(-15));
	  assertThrows(IndexOutOfBoundsException.class, () -> str.substring(-15, 7));
	}

}
