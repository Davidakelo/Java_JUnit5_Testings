/**
 * 
 */
/**
 * @author USERTEST
 *
 */
module lab1_JUnit {
	requires org.junit.jupiter.api;
}